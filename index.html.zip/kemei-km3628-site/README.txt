Kemei KM-3628 Landing Page

GitHub Pages:
1. Create a public GitHub repository.
2. Upload index.html and the entire assets folder (keep the folder name assets).
3. Open Settings > Pages.
4. Choose Deploy from a branch, branch main, folder /(root), then Save.
5. Wait for GitHub Pages to publish the site.

WhatsApp number is set to +212698727731.
Product price: 119 MAD. Delivery: 30 MAD. Total: 149 MAD.
